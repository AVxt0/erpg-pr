
# Be sure to keep an eye on ur discord every now and then
# just try to not get into jail xdd

# side note: dismantles everything in your inventory
# sells mob drops too
# read this before !!!!!!!!!

import pyautogui as pag
import time
import random

while True:
    pag.write('rpg dismantle epic fish all')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg dismantle golden fish all')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg dismantle trade a all')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg dismantle banana all')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg dismantle trade c all')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg dismantle trade e all')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg dismantle ultra log all')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg dismantle hyper log all')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg dismantle mega log all')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg dismantle super log all')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg dismantle epic log all')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg sell wooden log all')
    pag.enter('enter')