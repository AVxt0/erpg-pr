
# Be sure to keep an eye on ur discord every now and then
# just try to not get into jail xdd

# crafts in batches of 1000 epic logs

import pyautogui as pag
import time
import random

while True:
    pag.write('rpg craft epic log 1000')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg dismantle epic log all')
    pag.enter('enter')
    time.sleep(random.randint(1,2))