
# Be sure to keep an eye on ur discord every now and then
# just try to not get into jail xdd

# makes 100 banana pickaxe in batches

import pyautogui as pag
import time
import random

while True:
    pag.write('rpg trade d 150')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg craft banana 100')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg craft epic log 60000')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg craft super log 6000')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg craft mega log 600')
    pag.enter('enter')
    time.sleep(random.randint(1,2))
    pag.write('rpg cook banana pickaxe 100')
    pag.enter('enter')
    time.sleep(random.randint(1,2))