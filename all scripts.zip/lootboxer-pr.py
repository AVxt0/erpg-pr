print('there isnt one.....')
print('just be patient you lazy bastard')
input('')