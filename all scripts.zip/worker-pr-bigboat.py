
# Be sure to keep an eye on ur discord every now and then
# just try to not get into jail xdd

import pyautogui as pag
import time
import random

while True:
    pag.write('rpg bigboat')
    pag.enter('enter')
    time.sleep(random.randint(5,5.5))